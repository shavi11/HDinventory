<nav class="navbar navbar-light" style="background-color: #FFCB00;" <div class="container">
    <div class="row">
        <div class="container-fluid">
            <h1 style="color:#fff">TABLA DE COMPATIBLES</h1>
        </div>
    </div>
    </div>
</nav>
<?php $__env->startSection('seccion'); ?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VirtualTecnoDinamyc</title>

</head>

<body>

    <nav class="navbar navbar-expand-lg  bg-light">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary btn-lg btn-block">Volver</a>
    </nav>
    
    <div class="container-fluid" style="background-color: #0D6EFD ">
        <div class="row">

            <table class="table text-white table-bordered">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Tarjeta Logica</th>
                        <th scope="col">Modelo</th>
                        <th scope="col">Marca</th>
                        <th scope="col">Capacidad</th>
                        <th scope="col">Tipo de Entrada</th>
                        <th scope="col">Observaciones</th>
                     
                        <?php $__currentLoopData = $dis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                    <td><?php echo e($dis->id_numero); ?></td>
                    <td><?php echo e($dis->tarjetaLogica); ?></td>
                    <td><?php echo e($dis->modelo); ?></td>
                    <td><?php echo e($dis->marca); ?></td>
                    <td><?php echo e($dis->capacidad); ?></td>
                    <td><?php echo e($dis->tipoEntrada); ?></td>
                    <td><?php echo e($dis->observaciones); ?></td>
                    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
           
        </div>
        
    </div>
    
</body>
<nav class="navbar navbar-expand-lg  bg-light">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary btn-lg btn-block">Volver</a>
    </nav>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>