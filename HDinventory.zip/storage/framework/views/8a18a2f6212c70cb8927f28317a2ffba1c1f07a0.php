<head>
    <link rel="shortcut icon" href="./images/logoempresa.png" type="image/x-icon" />
</head>

<nav class="navbar navbar-light" style="background-color: #0D6EFD;" class="container">
    <div class="row">
        <div class="container-fluid">
            <h1 style="color:#fff">REGISTRO DE DISCO</h1>

        </div>
    </div>
    </div>
</nav>

<?php $__env->startSection('seccion'); ?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>TecnoVirtualDinamyc</title>

</head>

<?php if(session('mensaje')): ?>
<div class="alert alert-danger">
    <?php echo e(session('mensaje')); ?>

</div>

<?php endif; ?>


<!--<nav class="navbar navbar-expand-lg  bg-light">
                <a href="<?php echo e(url('/')); ?>" class="btn btn-secondary btn-lg btn-block">Volver</a>
    </nav>-->

<body>

    <header class="container-fluid" style="height: 720px; background-color: #0D6EFD ">
        <div class="row">
            <div class="col-12 align-self-center text-center placeholder-center">

                <form action="<?php echo e(route('disco.crear')); ?>" method="POST" enctype="multipart/form-data">
                    <div class="container">
                        <?php echo e(csrf_field()); ?>

                        <div class="col-md-4 col-md-offset-4 mt-md-5 ">
                            <div class="box box-primary">
                                <div class="panel panel-heading align-self-center">

                                    </br>
                                    <label form="id">ID</label>
                                    <input class="form-control <?php echo e($errors->has('id_numero')?'is-invalid':''); ?>" type="text" name="id_numero" id="idhd"
                                        placeholder="Ingrese el ID" value="<?php echo e(old('id_numero')); ?>">
                                        <?php echo $errors->first('id_numero','<div class="invalid-feedback">:message</div>'); ?>

                                    <br>

                                    <label form="TargetaLogica">Targeta Logica</label>
                                    <input class="form-control <?php echo e($errors->has('targetaLogica')?'is-invalid':''); ?>" type="text" name="targetaLogica" id="targetaL"
                                        Placeholder="Ingrese la targeta logica" value="<?php echo e(old('targetaLogica')); ?>">
                                        <?php echo $errors->first('targetaLogica','<div class="invalid-feedback">:message</div>'); ?>

                                    <br>

                                    <label form="Modelo">Modelo de Disco Duro</label>
                                    <input class="form-control <?php echo e($errors->has('modelo')?'is-invalid':''); ?>" type="text" name="modelo" id="model"
                                        Placeholder="Ingrese el modelo" value="<?php echo e(old('modelo')); ?>">
                                        <?php echo $errors->first('modelo','<div class="invalid-feedback">:message</div>'); ?>

                                    <br>

                                    <label form="Marca">Marca de Disco Duro</label>
                                    <input class="form-control <?php echo e($errors->has('marca')?'is-invalid':''); ?>" type="text" name="marca" id="marca"
                                        Placeholder="Ingrese la marca" value="<?php echo e(old('marca')); ?>">
                                    <?php echo $errors->first('marca','<div class="invalid-feedback">:message</div>'); ?>

                                    <br>
                                    <label form="Capacidad">Capacidad</label>
                                    <input class="form-control <?php echo e($errors->has('capacidad')?'is-invalid':''); ?>"
                                        type="text" name="capacidad" id="capacidad" Placeholder="Ingrese la capacidad"
                                        value="<?php echo e(old('capacidad')); ?>">
                                    <?php echo $errors->first('capacidad','<div class="invalid-feedback">:message</div>'); ?>

                                    <br>

                                    <label form="TipoEntrada">Tipo de entrada</label>
                                    <input class="form-control <?php echo e($errors->has('tipoEntrada')?'is-invalid':''); ?>" type="text" name="tipoEntrada" id="tipoEntrada"
                                        Placeholder="Ingrese el tipo de entrada" value="<?php echo e(old('tipoEntrada')); ?>">
                                        <?php echo $errors->first('tipoEntrada','<div class="invalid-feedback">:message</div>'); ?>

                                    <br>
                                    <label form="Observaciones">Observaciones</label>
                                    <input class="form-control" type="text" name="observaciones" id="Observaciones"
                                        value="<?php echo e(old('observaciones')); ?>">

                                    <br>
                                    <button type="submit" class="btn btn-success mb-5" value="Agregar"
                                        class>Registrar</button>
                                    <a href="<?php echo e(url('/')); ?>" class="btn btn-primary mb-5">Volver</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </header>
</body>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>