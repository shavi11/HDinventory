<?php $__env->startSection('seccion'); ?>

<!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>VirtualTecnoDinamyc</title>
        <link rel="shortcut icon" href="./images/logoempresa.png" type="image/x-icon"/>
        
    </head>
    <body>
         <div class="header">
            <div class="container-fluid text-white text-center" style=" background-color: #0D6EFD ">
            <h1 >Discos Compatibles</h1>
            </div>
          </div>  
          <form action="<?php echo e(route('editCompatible')); ?>" method="POST" enctype="multipart/form-data">
            <div class="container">
                 <?php echo e(csrf_field()); ?>

              <div class="d-flex justify-content-center" style="padding-top: 100px" >
                  <div class="box box-primary" >
                      <div class="panel panel-heading">
                        
                        <?php if(!empty($new)): ?>
                      
                            <h3>Tarjeta Logica: <?php echo e($new); ?> </h3>
                            <br>
                        <?php else: ?>
                                    <?php 
                                    $disco = DB::table('discos')
                                    ->where('bandera', 0)
                                    ->select('tarjetaLogica')
                                    ->first();
                                    ?>
                          <h3>Targeta Logica: <?php echo e($disco->tarjetaLogica); ?> </h3>
                        <?php endif; ?>
                        
                     
                        <input class="form-control" type="text" name="compatible" placeholder="Ingrese Disco Compatible"> 
                        <button class="btn btn-success mt-5" type="submit">Añadir</button>

                        <a href="<?php echo e(url('showDisk')); ?>"class="btn btn-primary mt-5">Terminar Registro</a>  
                     </div>      
                  </div>
               </div>
              </div>
            </form>  
            <table class="table table-light">
              <thead class="thead-light">
                <tr>
                  <th>Compatibles</th>
                </tr>
              </thead>
              <tbody>
                <?php $__currentLoopData = $dis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($dis->tarjeta_logica); ?></td>
                  <td>
                    <form action="<?php echo e(url('eliminarCompatible/'.$dis->id)); ?>" method="post" class="d-inline">
                      <?php echo e(csrf_field()); ?>

                      <?php echo e(method_field('DELETE')); ?>

                      <button class="btn btn-danger" type="submit">Eliminar</button>
                      </form> 
                  </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
    </body>






<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>